﻿namespace BMW_ONBOARDING_SYSTEM.Dtos
{
    public class GetAnswerOptionDto
    {
        public int Id { get; set; }
        public string Option { get; set; }
        public string Correct { get; set; }
    }
}