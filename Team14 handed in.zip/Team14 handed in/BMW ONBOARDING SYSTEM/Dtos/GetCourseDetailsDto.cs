﻿namespace BMW_ONBOARDING_SYSTEM.Dtos
{
    public class GetCourseDetailsDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}