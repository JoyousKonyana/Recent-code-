﻿namespace BMW_ONBOARDING_SYSTEM.Interfaces
{
    public class userauthorisationviewmodel
    {
    }
}