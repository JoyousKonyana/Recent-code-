﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class SendSmsViewModel
    {
        public string from { get; set; }
        public string to { get; set; }
        public string message { get; set; }

    }
}
