﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class CourseViewModel
    {
        
        public string CourseName { get; set; }

        public string CourseDescription { get; set; }

        public DateTime? CourseDueDate { get; set; }

       
    }
}
