﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class OTPViewModel
    {
        public int UserId { get; set; }
      
     
        public string OtpValue { get; set; }
      
        public DateTime Timestamp { get; set; }
       
       

    }
}
