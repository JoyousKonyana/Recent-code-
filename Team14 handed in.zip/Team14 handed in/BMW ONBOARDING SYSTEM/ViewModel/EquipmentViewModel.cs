﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class EquipmentViewModel
    {
        
       
      
        public int EquipmentTypeId { get; set; }
       
        public int EquipmentTradeInStatusId { get; set; }
       
        public int WarrantyId { get; set; }
      
        public int EquipmentBrandId { get; set; }
       
        public DateTime? EquipmentTradeInDeadline { get; set; }
      
        public string EquipmentSerialNumber { get; set; }

       
    
       
      
       
      
       
       
    }
}
