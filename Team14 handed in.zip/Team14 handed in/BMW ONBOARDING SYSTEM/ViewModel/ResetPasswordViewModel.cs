﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class ResetPasswordViewModel
    {

        public int UserId { get; set; }
   
      
        public string Password { get; set; }
    }
}
