﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class LessonViewModel
    {
        //public int? LessonId { get; set; }
     
        public int? CourseId { get; set; }
      
        public int? LessonCompletionStatusId { get; set; }
    
        public string LessonDescription { get; set; }
     
     

        public string LessonName { get; set; }

    }
}
