﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class ResolveQueryViewModel
    {
        public int EquipmentQueryId { get; set; }
        public int EquipmentQueryStatusId { get; set; }
    }
}
