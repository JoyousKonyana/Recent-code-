﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class LessonContentViewModel
    {
        public int LessonConentId { get; set; }
        public int? LessonContenetTypeId { get; set; }
        public int? LessonOutcomeId { get; set; }
        public int? ArchiveStatusId { get; set; }
        public string LessonContentDescription { get; set; }
        public string LessonContent1 { get; set; }


       

    }
}
