﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class CreateUserViewModel
    {
      
     
        public string Username { get; set; }
   
    
        public int? EmployeeId { get; set; }
     
        public int? UserRoleId { get; set; }


        

    }
}
