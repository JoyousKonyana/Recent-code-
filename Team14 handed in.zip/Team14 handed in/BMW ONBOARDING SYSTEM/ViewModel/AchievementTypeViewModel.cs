﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class AchievementTypeViewModel
    {
       
        public string AchievementTypeDescription { get; set; }
        public int? BadgeId { get; set; }

       
    }
}
