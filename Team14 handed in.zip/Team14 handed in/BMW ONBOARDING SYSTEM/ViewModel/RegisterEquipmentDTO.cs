﻿using BMW_ONBOARDING_SYSTEM.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class RegisterEquipmentDTO
    {
        //public List<Warranty> warranties = new List<Warranty>();
        public List<EquipmentType> equipmentTypes = new List<EquipmentType>();

    }
}
