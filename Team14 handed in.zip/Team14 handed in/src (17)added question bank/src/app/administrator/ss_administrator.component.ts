import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({ 
    templateUrl: 'ss_administrator.component.html',
    styleUrls: ['./ss_administrator.component.css']
})
export class SS_AdministratorComponent implements OnInit {

    constructor(
    ) {
    }

    ngOnInit() {
    }
}