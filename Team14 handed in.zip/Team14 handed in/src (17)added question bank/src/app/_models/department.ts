export class Department {
    DepatmentId!: number;
    DepartmentDescription!: string;
    }  