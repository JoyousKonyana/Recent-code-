export interface ForgotPassWord{
    Username:string
}