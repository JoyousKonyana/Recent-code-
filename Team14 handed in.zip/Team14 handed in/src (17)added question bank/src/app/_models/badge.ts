export class Badge{
    BadgeId!: number;
    BadgeDecription!: string;
}