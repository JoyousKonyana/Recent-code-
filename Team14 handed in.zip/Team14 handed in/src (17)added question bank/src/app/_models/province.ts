export class Province {
    ProvinceId!: number;
    ProvinceName!: string;
}