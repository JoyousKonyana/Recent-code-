export class Option {
    OptionId!: number;
    OptionNo!: number;
    OptionDescription!: string;
    QuestionId!: number;
}