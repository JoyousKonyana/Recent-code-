export class FAQ {
  Faqid!: number;
  Faqdescription: string | undefined;
  Faqanswer!: string;
  }

