export class ResolveQuery {
    EquipmentQueryId!: number;
    EquipmentQueryStatusId!: string;
}