export class User_Role {
    UserRoleId!: number;
    UserRoleDescription!: string;
    UserRoleName!: string;
}