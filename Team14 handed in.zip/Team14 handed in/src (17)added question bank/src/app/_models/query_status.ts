export class Query_Status {
    EquipmentQueryStatusId!: number;
    EquipmentQueryDescription!: string;
    }