export class Course {
  CourseId!: number;
  CourseDescription!: string;
  CourseDueDate!: string;
  CourseName!: string;
  } 