export class QuestionBank {
   CourseId!:number;
    
    LessonId!:number;
  
     LessonOutcomeId!:number;

    QuestionBankDescription!:string;
}