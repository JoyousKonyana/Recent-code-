export class EquipmentQuery {
    EquipmentId!: number;
    EquipmentQueryDescription!: number;
    EquipmentQueryDate!: Date;
}