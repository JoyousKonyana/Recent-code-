export class Country {
    countryId!: number;
    countryName!: string;
}