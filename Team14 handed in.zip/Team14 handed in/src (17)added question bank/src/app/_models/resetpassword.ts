export class ResetPassword{
    UserId!: any;
    Password!: string;
}