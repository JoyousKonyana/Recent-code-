export class ReportsModel{
    startDate!: Date;
    endDate!: Date;
}


   