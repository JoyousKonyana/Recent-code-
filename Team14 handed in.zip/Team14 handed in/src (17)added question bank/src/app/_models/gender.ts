export class Gender {
    GenderId!: number;
    GenderDescription!: string;
    }
  
  