export class submitquizDTO {
    QuestionId:Number; 
OptionId:Number;
}