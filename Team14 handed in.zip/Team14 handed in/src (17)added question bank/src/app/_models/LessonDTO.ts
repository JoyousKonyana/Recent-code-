export class LessonDTO {
    lessonID!: number;
    courseID!: number;
    lessonCompletionStatusId!: number;
    lessonDescription!: string;
    lessonName!: string;
}
