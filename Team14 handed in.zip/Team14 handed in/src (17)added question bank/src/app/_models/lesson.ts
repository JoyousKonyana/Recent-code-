export class Lesson {
    LessonId!: number;
     CourseId!: number;
    LessonCompletionStatusId!: number;
     LessonDescription!: string;
     LessonName!: string;
}