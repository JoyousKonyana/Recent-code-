export class Reg_Emp {
    EmployeeId!: number;
    DepartmentId!: number;
    UserRoleID!: number;
    GenderId!: number;
    AddressId!: number;
    EmployeeCalendarId!: string;
    FirstName!: string;
    LastName!: string;
    MiddleName!: string;
    Idnumber!: number;
    EmailAddress!: string;
    ContactNumber!: string;
    EmployeeJobTitle!: string;
    TitleId!: number;
    SuburbId!: number;
    ProvinceId!: number;
    CityId!: number;
    CountryId!: number;
    StreetNumber!: number;
    StreetName!: string;
}
