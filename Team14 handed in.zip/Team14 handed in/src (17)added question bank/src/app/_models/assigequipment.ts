export class AssignEquipment {
    EquipmentId!: number;
    OnboarderId!: number;
   EquipmentCheckOutDate!: Date;
    EquipmentCheckOutCondition!: string;
    EquipmentCheckInDate!: Date;
     EquipmentCheckInCondition!: string;
}