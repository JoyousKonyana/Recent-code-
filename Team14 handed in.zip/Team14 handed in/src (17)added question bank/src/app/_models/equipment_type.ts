export class Equipment_Type {
    EquipmentTypeId!: number;
    EquipmentTypeDescription!: string;
    }
  
   