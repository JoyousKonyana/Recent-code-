export class Achievment_Type {
    AchievementTypeId!: number;
    AchievementTypeDescription!: string;
    BadgeId!: number;
    }

 