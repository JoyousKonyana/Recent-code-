export class Audit_Log{
    AuditLogId!: number;
    UserId!: number;
    AuditLogDatestamp!: string;
    AuditLogTimestamp!: string;
    AuditLogDescription!: string;
}