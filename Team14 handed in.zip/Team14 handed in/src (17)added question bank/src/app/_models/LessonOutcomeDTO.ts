export class LessonOutcomeDTO {
    lessonOutcomeID!: number;
    lessonID!: number;
    lessonOutcomeDescription!: string;
    lessonOutcomeName!: string;

}
