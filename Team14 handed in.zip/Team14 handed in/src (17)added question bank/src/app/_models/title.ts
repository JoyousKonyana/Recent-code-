export class Title {
    TitleId!: number;
    TitleDescription!: string;
}
