export class Quiz {
    QuizId!: number;
    LessonOutcomeId!: number;
    QuizDescription!: string;
    QuizMarkRequirement!: string;
    QuizDueDate!: string;
    QuizCompletionDate!: string;
    NumberOfQuestions!: number;
}