export class AssignCourse{
    OnboarderId!: number;
    CourseId!: number;
    OnboarderEnrollmentDate!: Date;
}