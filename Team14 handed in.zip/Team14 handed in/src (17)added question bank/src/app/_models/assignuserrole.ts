export class AssignUserRole{
    User_ID!: number;
   
    UserRoleID!: number;
}