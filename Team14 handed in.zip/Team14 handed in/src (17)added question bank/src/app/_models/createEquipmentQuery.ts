export class EquipmentQuery {
    EquipmentId!: number;
    EquipmentQueryDescription!: string;
    EquipmentQueryDate!: string;
    OnboarderId!: number;


}

