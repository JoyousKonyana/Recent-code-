

export class Equipment_Query {
    EquipmentId!: number;
    OnboarderId!: number;
    EquipmentQueryDescription!: string;
    EquipmentQueryDate!: string;
}
