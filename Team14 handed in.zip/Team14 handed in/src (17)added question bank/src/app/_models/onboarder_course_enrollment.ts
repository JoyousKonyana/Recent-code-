export class Onboarder_Course_Enrollment {
    OnboarderId!: number;
    CourseId!: number;
    OnboarderEnrollmentDate!: string;
  }