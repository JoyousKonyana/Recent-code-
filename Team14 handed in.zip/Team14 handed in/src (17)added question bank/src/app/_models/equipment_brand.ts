export class Equipment_Brand {
    EquipmentBrandId!: number;
    EquipmentTypeDescription!: string;
    }
  