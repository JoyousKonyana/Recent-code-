export class ProgressReport {
    onboarderID!: number;
    courseID!: number;
}