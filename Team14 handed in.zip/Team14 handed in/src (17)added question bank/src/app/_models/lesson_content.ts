
export class Lesson_Content {
  LessonConentId!: number;
  LessonContenetTypeId!: number;
  LessonOutcomeId!: number;
  ArchiveStatusId!: number;
  LessonContentDescription!: string;
  LessonContent1!: string;
  }

