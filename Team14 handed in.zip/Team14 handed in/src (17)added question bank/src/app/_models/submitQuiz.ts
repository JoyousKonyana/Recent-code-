export class submitQuiz {
    QuestionId!: number;
    OptionId!: string;
}