export class Onboarder_Equipment {
    EquipmentId!: number; 
    OnboarderId!: number; 
    EquipmentCheckOutDate!: string;  
    EquipmentCheckOutCondition!: string; 
    EquipmentCheckInDate!: string;
    EquipmentCheckInCondition!: string;
  }