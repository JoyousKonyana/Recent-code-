export interface OTP {
    UserId: number;
    OtpValue: string;
  }