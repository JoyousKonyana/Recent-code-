export class CheckOut {
    EquipmentId!: number;
    OnboarderId!: number;
    EquipmentCheckOutDate!: number;
    EquipmentCheckOutCondition!: number;
}