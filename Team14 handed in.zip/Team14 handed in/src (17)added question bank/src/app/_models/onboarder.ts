export class Onboarder {
    Onboarder_ID: number | undefined;
    Employee_ID!: number;
    Equipment_Type_ID!: number;
    Booking_ID!: number;
    Suggestion_ID!: number;
    Registration_ID!: number;
  }