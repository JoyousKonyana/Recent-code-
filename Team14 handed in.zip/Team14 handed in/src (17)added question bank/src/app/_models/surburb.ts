export class Surburb {
    suburbId!: number;
    suburbName!: string;
}