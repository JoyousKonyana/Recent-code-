export class Learning_Outcome {
  LessonOutcomeId!: number;
  LessonId!: number;
  LessonOutcomeDescription!: string;
  LessonOutcomeName!: string;
  }

 