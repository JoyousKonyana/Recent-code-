import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { first } from 'rxjs/operators';

@Component({ 
    templateUrl: 'ss_equipment.component.html',
    styleUrls: ['./ss_equipment.component.css']
})
export class SS_EquipmentComponent implements OnInit {

    constructor(
    ) {
    }

    ngOnInit() {
    }
}