﻿ export * from './login.component';
 export * from './otp.component';
 export * from './forgotpassword.component';